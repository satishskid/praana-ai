// Application Data
const APP_DATA = {
  breathingTechniques: [
    {
      name: "Box Breathing",
      pattern: [4, 4, 4, 4],
      description: "Equal inhale, hold, exhale, hold pattern",
      difficulty: "beginner",
      duration: [5, 10, 15, 20, 30]
    },
    {
      name: "Triangle Breathing", 
      pattern: [4, 4, 4],
      description: "Inhale, hold, exhale in equal measures",
      difficulty: "beginner",
      duration: [5, 10, 15, 20, 30]
    },
    {
      name: "Nadi Shodhana",
      pattern: [4, 2, 6, 2],
      description: "Alternate nostril breathing technique",
      difficulty: "intermediate", 
      duration: [10, 15, 20, 30]
    },
    {
      name: "Diaphragmatic Breathing",
      pattern: [6, 2, 8, 2],
      description: "Deep belly breathing for relaxation",
      difficulty: "beginner",
      duration: [5, 10, 15, 20, 30]
    }
  ],
  meditationActivities: [
    {
      name: "Morning Walk",
      type: "walking",
      duration: [10, 15, 20, 30, 45],
      coachingPrompts: [
        "Focus on your breath as you walk",
        "Notice the sounds around you",
        "Feel your feet connecting with the ground",
        "Breathe in sync with your steps"
      ]
    },
    {
      name: "Evening Walk", 
      type: "walking",
      duration: [10, 15, 20, 30, 45],
      coachingPrompts: [
        "Let go of the day's stress with each exhale",
        "Appreciate the evening air",
        "Walk with mindful awareness",
        "Find peace in the rhythm of walking"
      ]
    },
    {
      name: "Stretching Session",
      type: "stretching", 
      duration: [5, 10, 15, 20],
      coachingPrompts: [
        "Breathe deeply into each stretch",
        "Release tension with your exhale", 
        "Move with gentle awareness",
        "Honor your body's limits"
      ]
    }
  ],
  sensorProfiles: [
    {
      name: "Polar H10",
      type: "heart_rate_monitor",
      metrics: ["HR", "HRV"],
      services: {"heart_rate": "180D", "hrv": "2A37"},
      accuracy: {"hr": "±3 BPM", "hrv": "±10 ms"}
    },
    {
      name: "Nonin 3012LP",
      type: "pulse_oximeter", 
      metrics: ["HR", "SpO2"],
      services: {"pulse_ox": "1822", "heart_rate": "180D"},
      accuracy: {"hr": "±3 BPM", "spo2": "±2%"}
    },
    {
      name: "Camera PPG",
      type: "camera_sensor",
      metrics: ["HR", "HRV"],
      method: "photoplethysmography",
      accuracy: {"hr": "±5 BPM", "hrv": "±15 ms"}
    }
  ],
  achievements: [
    {"name": "First Session", "description": "Complete your first breathing session", "icon": "🌟"},
    {"name": "Daily Practice", "description": "Practice for 7 consecutive days", "icon": "🔥"},
    {"name": "Mindful Walker", "description": "Complete 10 meditation walks", "icon": "🚶"},
    {"name": "Breathing Master", "description": "Practice for 30 days total", "icon": "🏆"},
    {"name": "Stress Buster", "description": "Achieve calm state 50 times", "icon": "😌"},
    {"name": "Early Bird", "description": "Complete 10 morning sessions", "icon": "🌅"},
    {"name": "Night Owl", "description": "Complete 10 evening sessions", "icon": "🌙"}
  ],
  vitalSignsRanges: {
    heartRate: {min: 60, max: 100, optimal: [65, 85]},
    hrv: {min: 20, max: 50, optimal: [30, 45]},
    spo2: {min: 95, max: 100, optimal: [97, 100]},
    breathingRate: {min: 12, max: 20, optimal: [14, 18]}
  }
};

// Application State
let appState = {
  currentScreen: 'welcomeScreen',
  user: null,
  currentSession: null,
  sessionTimer: null,
  breathingTimer: null,
  vitalSignsTimer: null,
  selectedTechnique: null,
  selectedActivity: null,
  sessionDuration: 10,
  sessionStartTime: null,
  breathCount: 0,
  currentBreathPhase: 0,
  isPaused: false,
  connectedDevices: [],
  sessionHistory: [],
  vitalSigns: {
    hr: 72,
    hrv: 35,
    spo2: 98,
    breathingRate: 16,
    stressLevel: 0.5
  }
};

// Utility Functions
function saveToLocalStorage(key, data) {
  try {
    localStorage.setItem(`pranayama_${key}`, JSON.stringify(data));
  } catch (error) {
    console.warn('Failed to save to localStorage:', error);
  }
}

function loadFromLocalStorage(key) {
  try {
    const data = localStorage.getItem(`pranayama_${key}`);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.warn('Failed to load from localStorage:', error);
    return null;
  }
}

function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

function generateRealisticVitalSigns(breathPhase, sessionDuration) {
  const baseHR = 72;
  const baseHRV = 35;
  const baseSpo2 = 98;
  const baseBreathRate = 16;

  // Simulate breathing-correlated changes
  let hrVariation = 0;
  let hrvVariation = 0;
  let stressVariation = 0;

  if (breathPhase === 'inhale') {
    hrVariation = Math.random() * 4 - 2; // -2 to +2
    hrvVariation = Math.random() * 3 + 1; // +1 to +4
    stressVariation = -0.1;
  } else if (breathPhase === 'exhale') {
    hrVariation = Math.random() * 3 - 5; // -5 to -2
    hrvVariation = Math.random() * 5 + 2; // +2 to +7
    stressVariation = -0.2;
  }

  // Progressive relaxation over session duration
  const relaxationFactor = Math.min(sessionDuration / 600, 1); // Max after 10 minutes
  const overallStressReduction = relaxationFactor * 0.3;

  appState.vitalSigns.hr = Math.max(60, Math.min(100, baseHR + hrVariation - (relaxationFactor * 8)));
  appState.vitalSigns.hrv = Math.max(20, Math.min(50, baseHRV + hrvVariation + (relaxationFactor * 10)));
  appState.vitalSigns.spo2 = Math.max(95, Math.min(100, baseSpo2 + Math.random() * 2 - 1));
  appState.vitalSigns.breathingRate = Math.max(12, Math.min(20, baseBreathRate - (relaxationFactor * 2)));
  appState.vitalSigns.stressLevel = Math.max(0, Math.min(1, 
    appState.vitalSigns.stressLevel + stressVariation - overallStressReduction));
}

// Screen Management
function showScreen(screenId) {
  document.querySelectorAll('.screen').forEach(screen => {
    screen.classList.remove('active');
  });
  document.getElementById(screenId).classList.add('active');
  appState.currentScreen = screenId;
}

function showOnboarding() {
  showScreen('onboardingScreen');
}

function showDashboard() {
  showScreen('dashboardScreen');
  updateDashboard();
}

function showPranayamaSessions() {
  showScreen('pranayamaScreen');
  loadPranayamaTechniques();
}

function showMeditationZone() {
  showScreen('meditationScreen');
  loadMeditationActivities();
}

function showSensorManagement() {
  showScreen('sensorScreen');
  loadSensorManagement();
}

function showAnalytics() {
  showScreen('analyticsScreen');
  loadAnalytics();
}

function showSettings() {
  showScreen('settingsScreen');
  loadSettings();
}

// Onboarding
function completeOnboarding() {
  const userName = document.getElementById('userName').value;
  const userAge = document.getElementById('userAge').value;
  const goals = Array.from(document.querySelectorAll('.goal-option input[type="checkbox"]:checked'))
    .map(checkbox => checkbox.value);
  const experienceLevel = document.getElementById('experienceLevel').value;
  const privacyConsent = document.getElementById('privacyConsent').checked;

  if (!userName || !userAge || !privacyConsent) {
    alert('Please fill in all required fields and accept the privacy policy.');
    return;
  }

  appState.user = {
    name: userName,
    age: parseInt(userAge),
    goals: goals,
    experienceLevel: experienceLevel,
    joinDate: new Date().toISOString(),
    privacyConsent: privacyConsent,
    consentTimestamp: new Date().toISOString()
  };

  saveToLocalStorage('user', appState.user);
  saveToLocalStorage('sessionHistory', []);
  saveToLocalStorage('achievements', []);

  showDashboard();
}

// Dashboard Updates
function updateDashboard() {
  if (!appState.user) return;

  document.getElementById('dashboardUserName').textContent = appState.user.name;
  
  const sessionHistory = loadFromLocalStorage('sessionHistory') || [];
  const achievements = loadFromLocalStorage('achievements') || [];
  
  // Calculate streak
  const today = new Date().toDateString();
  const yesterday = new Date(Date.now() - 86400000).toDateString();
  const hasSessionToday = sessionHistory.some(session => 
    new Date(session.date).toDateString() === today);
  const hasSessionYesterday = sessionHistory.some(session => 
    new Date(session.date).toDateString() === yesterday);
  
  let streak = hasSessionToday ? 1 : 0;
  if (hasSessionToday && hasSessionYesterday) {
    // Calculate actual streak (simplified)
    streak = Math.min(sessionHistory.length, 30);
  }

  document.getElementById('todayStreak').textContent = streak;
  document.getElementById('totalSessions').textContent = sessionHistory.length;
  document.getElementById('totalMinutes').textContent = 
    sessionHistory.reduce((total, session) => total + session.duration, 0);
  document.getElementById('achievementCount').textContent = achievements.length;

  updateVitalSignsDisplay();
  startVitalSignsSimulation();
}

function updateVitalSignsDisplay() {
  document.getElementById('currentHR').textContent = Math.round(appState.vitalSigns.hr);
  document.getElementById('currentHRV').textContent = Math.round(appState.vitalSigns.hrv);
  document.getElementById('currentSpO2').textContent = Math.round(appState.vitalSigns.spo2);
  document.getElementById('currentBreathRate').textContent = Math.round(appState.vitalSigns.breathingRate);

  // Update stress level
  const stressLevel = document.getElementById('stressLevel');
  const stressText = document.getElementById('stressText');
  const stressPercentage = appState.vitalSigns.stressLevel * 100;
  
  stressLevel.style.width = `${stressPercentage}%`;
  
  if (stressPercentage < 30) {
    stressText.textContent = 'Calm';
    stressText.style.color = '#10b981';
  } else if (stressPercentage < 70) {
    stressText.textContent = 'Balanced';
    stressText.style.color = '#f59e0b';
  } else {
    stressText.textContent = 'Stressed';
    stressText.style.color = '#ef4444';
  }
}

function startVitalSignsSimulation() {
  if (appState.vitalSignsTimer) {
    clearInterval(appState.vitalSignsTimer);
  }

  appState.vitalSignsTimer = setInterval(() => {
    generateRealisticVitalSigns('rest', 0);
    updateVitalSignsDisplay();
    
    // Update session vitals if in session
    if (appState.currentSession) {
      updateSessionVitals();
    }
  }, 2000);
}

// Pranayama Sessions
function loadPranayamaTechniques() {
  const grid = document.getElementById('techniquesGrid');
  grid.innerHTML = '';

  APP_DATA.breathingTechniques.forEach(technique => {
    const card = document.createElement('div');
    card.className = 'technique-card';
    card.onclick = () => configurePranayamaSession(technique);

    const patternText = technique.pattern.length === 4 ? 
      `${technique.pattern[0]}-${technique.pattern[1]}-${technique.pattern[2]}-${technique.pattern[3]}` :
      `${technique.pattern[0]}-${technique.pattern[1]}-${technique.pattern[2]}`;

    card.innerHTML = `
      <div class="technique-header">
        <h3 class="technique-title">${technique.name}</h3>
        <span class="difficulty-badge difficulty-${technique.difficulty}">${technique.difficulty}</span>
      </div>
      <div class="technique-pattern">${patternText}</div>
      <p>${technique.description}</p>
    `;

    grid.appendChild(card);
  });
}

function configurePranayamaSession(technique) {
  appState.selectedTechnique = technique;
  appState.selectedActivity = null;
  showScreen('sessionConfigScreen');
  
  document.getElementById('configTitle').textContent = `Configure ${technique.name}`;
  
  const durationOptions = document.getElementById('durationOptions');
  durationOptions.innerHTML = '';
  
  technique.duration.forEach(duration => {
    const btn = document.createElement('button');
    btn.className = 'duration-btn';
    btn.textContent = `${duration} min`;
    btn.onclick = () => selectDuration(duration);
    durationOptions.appendChild(btn);
  });
  
  // Select default duration
  selectDuration(technique.duration[1] || technique.duration[0]);
}

// Meditation Activities
function loadMeditationActivities() {
  const grid = document.getElementById('meditationGrid');
  grid.innerHTML = '';

  APP_DATA.meditationActivities.forEach(activity => {
    const card = document.createElement('div');
    card.className = 'meditation-card';
    card.onclick = () => configureMeditationSession(activity);

    const icon = activity.type === 'walking' ? '🚶‍♀️' : '🧘‍♀️';

    card.innerHTML = `
      <div class="meditation-header">
        <div>
          <div style="font-size: 2rem; margin-bottom: 8px;">${icon}</div>
          <h3 class="meditation-title">${activity.name}</h3>
        </div>
      </div>
      <p>Guided ${activity.type} meditation with audio coaching</p>
      <p><strong>Duration:</strong> ${activity.duration[0]}-${activity.duration[activity.duration.length-1]} minutes</p>
    `;

    grid.appendChild(card);
  });
}

function configureMeditationSession(activity) {
  appState.selectedActivity = activity;
  appState.selectedTechnique = null;
  showScreen('sessionConfigScreen');
  
  document.getElementById('configTitle').textContent = `Configure ${activity.name}`;
  
  const durationOptions = document.getElementById('durationOptions');
  durationOptions.innerHTML = '';
  
  activity.duration.forEach(duration => {
    const btn = document.createElement('button');
    btn.className = 'duration-btn';
    btn.textContent = `${duration} min`;
    btn.onclick = () => selectDuration(duration);
    durationOptions.appendChild(btn);
  });
  
  selectDuration(activity.duration[1] || activity.duration[0]);
}

function selectDuration(duration) {
  appState.sessionDuration = duration;
  document.querySelectorAll('.duration-btn').forEach(btn => {
    btn.classList.remove('selected');
  });
  event.target.classList.add('selected');
}

function goBackFromConfig() {
  if (appState.selectedTechnique) {
    showPranayamaSessions();
  } else {
    showMeditationZone();
  }
}

// Session Management
function startSession() {
  appState.currentSession = {
    type: appState.selectedTechnique ? 'pranayama' : 'meditation',
    technique: appState.selectedTechnique,
    activity: appState.selectedActivity,
    duration: appState.sessionDuration,
    startTime: Date.now(),
    vitalHistory: [],
    breathCount: 0
  };

  appState.sessionStartTime = Date.now();
  appState.breathCount = 0;
  appState.currentBreathPhase = 0;
  appState.isPaused = false;

  showScreen('sessionScreen');
  startSessionTimer();

  if (appState.selectedTechnique) {
    startBreathingPattern();
  } else {
    startMeditationSession();
  }
}

function startSessionTimer() {
  let elapsedSeconds = 0;
  const totalSeconds = appState.sessionDuration * 60;

  appState.sessionTimer = setInterval(() => {
    if (!appState.isPaused) {
      elapsedSeconds++;
      document.getElementById('sessionTimer').textContent = formatTime(elapsedSeconds);
      
      if (elapsedSeconds >= totalSeconds) {
        completeSession();
      }
    }
  }, 1000);
}

function startBreathingPattern() {
  const technique = appState.selectedTechnique;
  const pattern = technique.pattern;
  const phases = pattern.length === 4 ? 
    ['Inhale', 'Hold', 'Exhale', 'Hold'] : 
    ['Inhale', 'Hold', 'Exhale'];

  let phaseIndex = 0;
  let phaseTimeRemaining = pattern[0];

  function updateBreathingInstruction() {
    if (appState.isPaused) return;

    const instruction = document.getElementById('breathInstruction');
    const counter = document.getElementById('breathCounter');
    const circle = document.getElementById('breathCircle');

    instruction.textContent = phases[phaseIndex];
    counter.textContent = phaseTimeRemaining;

    // Apply visual effects
    circle.className = 'breath-circle';
    if (phases[phaseIndex] === 'Inhale') {
      circle.classList.add('inhale');
      generateRealisticVitalSigns('inhale', (Date.now() - appState.sessionStartTime) / 1000);
    } else if (phases[phaseIndex] === 'Exhale') {
      circle.classList.add('exhale');
      generateRealisticVitalSigns('exhale', (Date.now() - appState.sessionStartTime) / 1000);
    } else {
      circle.classList.add('hold');
      generateRealisticVitalSigns('hold', (Date.now() - appState.sessionStartTime) / 1000);
    }

    phaseTimeRemaining--;

    if (phaseTimeRemaining < 0) {
      phaseIndex = (phaseIndex + 1) % pattern.length;
      phaseTimeRemaining = pattern[phaseIndex];
      
      if (phaseIndex === 0) {
        appState.breathCount++;
      }
    }
  }

  updateBreathingInstruction();
  appState.breathingTimer = setInterval(updateBreathingInstruction, 1000);
}

function startMeditationSession() {
  const activity = appState.selectedActivity;
  const prompts = activity.coachingPrompts;
  let promptIndex = 0;

  function showCoachingPrompt() {
    if (appState.isPaused) return;

    const promptsElement = document.getElementById('coachingPrompts');
    promptsElement.textContent = prompts[promptIndex];
    promptsElement.classList.add('visible');

    setTimeout(() => {
      promptsElement.classList.remove('visible');
    }, 4000);

    promptIndex = (promptIndex + 1) % prompts.length;
  }

  // Show initial prompt
  setTimeout(showCoachingPrompt, 2000);
  
  // Show prompts every 30 seconds
  appState.breathingTimer = setInterval(showCoachingPrompt, 30000);

  // Set meditation breathing visualization
  document.getElementById('breathInstruction').textContent = 'Breathe Naturally';
  document.getElementById('breathCounter').textContent = '';
}

function updateSessionVitals() {
  document.getElementById('sessionHR').textContent = Math.round(appState.vitalSigns.hr);
  document.getElementById('sessionHRV').textContent = Math.round(appState.vitalSigns.hrv);
  document.getElementById('sessionSpO2').textContent = Math.round(appState.vitalSigns.spo2);
  document.getElementById('sessionBR').textContent = Math.round(appState.vitalSigns.breathingRate);

  // Store vital signs history
  if (appState.currentSession) {
    appState.currentSession.vitalHistory.push({
      timestamp: Date.now(),
      hr: appState.vitalSigns.hr,
      hrv: appState.vitalSigns.hrv,
      spo2: appState.vitalSigns.spo2,
      breathingRate: appState.vitalSigns.breathingRate,
      stressLevel: appState.vitalSigns.stressLevel
    });
  }
}

function togglePause() {
  appState.isPaused = !appState.isPaused;
  const pauseBtn = document.getElementById('pauseBtn');
  pauseBtn.textContent = appState.isPaused ? '▶️ Resume' : '⏸️ Pause';
}

function endSession() {
  if (confirm('Are you sure you want to end this session?')) {
    completeSession();
  }
}

function completeSession() {
  // Clear timers
  if (appState.sessionTimer) {
    clearInterval(appState.sessionTimer);
    appState.sessionTimer = null;
  }
  if (appState.breathingTimer) {
    clearInterval(appState.breathingTimer);
    appState.breathingTimer = null;
  }

  // Calculate session stats
  const sessionDuration = Math.round((Date.now() - appState.sessionStartTime) / 1000 / 60);
  const vitalHistory = appState.currentSession.vitalHistory;
  
  const avgHR = vitalHistory.length > 0 ? 
    Math.round(vitalHistory.reduce((sum, v) => sum + v.hr, 0) / vitalHistory.length) : 
    appState.vitalSigns.hr;
  
  const avgHRV = vitalHistory.length > 0 ?
    Math.round(vitalHistory.reduce((sum, v) => sum + v.hrv, 0) / vitalHistory.length) :
    appState.vitalSigns.hrv;

  const finalStressLevel = appState.vitalSigns.stressLevel;
  const stressText = finalStressLevel < 0.3 ? 'Calm' : finalStressLevel < 0.7 ? 'Balanced' : 'Stressed';

  // Save session to history
  const sessionRecord = {
    id: Date.now(),
    date: new Date().toISOString(),
    type: appState.currentSession.type,
    technique: appState.currentSession.technique?.name,
    activity: appState.currentSession.activity?.name,
    duration: sessionDuration,
    breathCount: appState.breathCount,
    avgHR: avgHR,
    avgHRV: avgHRV,
    finalStressLevel: stressText,
    vitalHistory: vitalHistory
  };

  const sessionHistory = loadFromLocalStorage('sessionHistory') || [];
  sessionHistory.push(sessionRecord);
  saveToLocalStorage('sessionHistory', sessionHistory);

  // Check for new achievements
  const newAchievements = checkAchievements(sessionHistory);

  // Show summary
  showSessionSummary(sessionRecord, newAchievements);
  appState.currentSession = null;
}

function showSessionSummary(session, newAchievements) {
  showScreen('summaryScreen');
  
  document.getElementById('summaryTechnique').textContent = 
    session.technique || session.activity || 'Meditation';
  document.getElementById('summaryDuration').textContent = `${session.duration} minutes`;
  document.getElementById('summaryAvgHR').textContent = session.avgHR;
  document.getElementById('summaryAvgHRV').textContent = session.avgHRV;
  document.getElementById('summaryStress').textContent = session.finalStressLevel;

  // Show new achievements
  const achievementsEarned = document.getElementById('achievementsEarned');
  achievementsEarned.innerHTML = '';

  if (newAchievements.length > 0) {
    const title = document.createElement('h4');
    title.textContent = 'New Achievements! 🎉';
    achievementsEarned.appendChild(title);

    newAchievements.forEach(achievement => {
      const achievementDiv = document.createElement('div');
      achievementDiv.className = 'achievement-notification';
      achievementDiv.innerHTML = `
        <span style="font-size: 1.5rem;">${achievement.icon}</span>
        <div>
          <strong>${achievement.name}</strong>
          <p style="margin: 0; opacity: 0.9;">${achievement.description}</p>
        </div>
      `;
      achievementsEarned.appendChild(achievementDiv);
    });
  }
}

function checkAchievements(sessionHistory) {
  const existingAchievements = loadFromLocalStorage('achievements') || [];
  const newAchievements = [];

  APP_DATA.achievements.forEach(achievement => {
    if (existingAchievements.some(a => a.name === achievement.name)) {
      return; // Already earned
    }

    let earned = false;

    switch (achievement.name) {
      case 'First Session':
        earned = sessionHistory.length >= 1;
        break;
      case 'Daily Practice':
        earned = checkConsecutiveDays(sessionHistory, 7);
        break;
      case 'Mindful Walker':
        earned = sessionHistory.filter(s => s.type === 'meditation').length >= 10;
        break;
      case 'Breathing Master':
        earned = sessionHistory.length >= 30;
        break;
      case 'Stress Buster':
        earned = sessionHistory.filter(s => s.finalStressLevel === 'Calm').length >= 50;
        break;
      case 'Early Bird':
        earned = sessionHistory.filter(s => {
          const hour = new Date(s.date).getHours();
          return hour >= 5 && hour < 10;
        }).length >= 10;
        break;
      case 'Night Owl':
        earned = sessionHistory.filter(s => {
          const hour = new Date(s.date).getHours();
          return hour >= 20 || hour < 5;
        }).length >= 10;
        break;
    }

    if (earned) {
      newAchievements.push(achievement);
      existingAchievements.push({
        ...achievement,
        earnedDate: new Date().toISOString()
      });
    }
  });

  saveToLocalStorage('achievements', existingAchievements);
  return newAchievements;
}

function checkConsecutiveDays(sessionHistory, targetDays) {
  if (sessionHistory.length < targetDays) return false;

  const sortedSessions = sessionHistory
    .map(s => new Date(s.date).toDateString())
    .filter((date, index, array) => array.indexOf(date) === index)
    .sort((a, b) => new Date(b) - new Date(a));

  let consecutiveDays = 1;
  let currentDate = new Date(sortedSessions[0]);

  for (let i = 1; i < sortedSessions.length; i++) {
    const prevDate = new Date(sortedSessions[i]);
    const dayDiff = (currentDate - prevDate) / (1000 * 60 * 60 * 24);
    
    if (dayDiff === 1) {
      consecutiveDays++;
      if (consecutiveDays >= targetDays) return true;
    } else if (dayDiff > 1) {
      break;
    }
    
    currentDate = prevDate;
  }

  return false;
}

// Sensor Management
function loadSensorManagement() {
  const deviceList = document.getElementById('deviceList');
  const connectedDevices = document.getElementById('connectedDevices');
  
  deviceList.innerHTML = '';
  
  if (appState.connectedDevices.length === 0) {
    connectedDevices.innerHTML = '<p>No devices connected</p>';
  } else {
    connectedDevices.innerHTML = '';
    appState.connectedDevices.forEach(device => {
      const deviceDiv = document.createElement('div');
      deviceDiv.className = 'connected-device';
      deviceDiv.innerHTML = `
        <div>
          <h4>${device.name}</h4>
          <p>Status: Connected</p>
        </div>
        <button class="btn btn--outline btn--sm" onclick="disconnectDevice('${device.id}')">Disconnect</button>
      `;
      connectedDevices.appendChild(deviceDiv);
    });
  }
}

function scanForDevices() {
  const scanBtn = document.getElementById('scanBtn');
  const scanningIndicator = document.getElementById('scanningIndicator');
  const deviceList = document.getElementById('deviceList');

  scanBtn.disabled = true;
  scanningIndicator.style.display = 'block';
  deviceList.innerHTML = '';

  // Simulate device discovery
  setTimeout(() => {
    const simulatedDevices = [
      { id: 'polar_h10_001', name: 'Polar H10', type: 'heart_rate_monitor', rssi: -45 },
      { id: 'nonin_3012_001', name: 'Nonin 3012LP', type: 'pulse_oximeter', rssi: -52 },
      { id: 'unknown_device_001', name: 'Health Sensor', type: 'unknown', rssi: -68 }
    ];

    simulatedDevices.forEach(device => {
      const deviceDiv = document.createElement('div');
      deviceDiv.className = 'device-item';
      deviceDiv.innerHTML = `
        <div class="device-info">
          <h4>${device.name}</h4>
          <p>Type: ${device.type.replace('_', ' ')} | Signal: ${device.rssi} dBm</p>
        </div>
        <button class="btn btn--primary btn--sm" onclick="connectDevice('${device.id}', '${device.name}', '${device.type}')">Connect</button>
      `;
      deviceList.appendChild(deviceDiv);
    });

    scanningIndicator.style.display = 'none';
    scanBtn.disabled = false;
  }, 3000);
}

function connectDevice(deviceId, deviceName, deviceType) {
  // Simulate connection
  const device = {
    id: deviceId,
    name: deviceName,
    type: deviceType,
    connectedAt: new Date().toISOString()
  };

  appState.connectedDevices.push(device);
  loadSensorManagement();
  
  alert(`Successfully connected to ${deviceName}`);
}

function disconnectDevice(deviceId) {
  appState.connectedDevices = appState.connectedDevices.filter(device => device.id !== deviceId);
  loadSensorManagement();
}

function testCameraPPG() {
  const cameraStatus = document.getElementById('cameraStatus');
  cameraStatus.className = 'camera-status testing';
  cameraStatus.textContent = 'Testing camera PPG... Place finger over camera lens';

  setTimeout(() => {
    cameraStatus.className = 'camera-status success';
    cameraStatus.textContent = 'Camera PPG test successful! Heart rate detected: 72 BPM';
  }, 5000);
}

// Analytics
function loadAnalytics() {
  showAnalyticsTab('overview');
}

function showAnalyticsTab(tabName) {
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

  event?.target?.classList.add('active') || document.querySelector(`.tab-btn`).classList.add('active');
  document.getElementById(`${tabName}Tab`).classList.add('active');

  if (tabName === 'overview') {
    loadAnalyticsCharts();
  } else if (tabName === 'sessions') {
    loadSessionHistory();
  } else if (tabName === 'achievements') {
    loadAchievementsDisplay();
  }
}

function loadAnalyticsCharts() {
  const sessionHistory = loadFromLocalStorage('sessionHistory') || [];
  
  // Progress Chart
  setTimeout(() => {
    const ctx1 = document.getElementById('progressChart');
    if (ctx1) {
      new Chart(ctx1, {
        type: 'line',
        data: {
          labels: sessionHistory.slice(-14).map(s => new Date(s.date).toLocaleDateString()),
          datasets: [{
            label: 'Session Duration (minutes)',
            data: sessionHistory.slice(-14).map(s => s.duration),
            borderColor: '#1FB8CD',
            backgroundColor: 'rgba(31, 184, 205, 0.1)',
            tension: 0.4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: true,
              text: 'Session Duration Over Time'
            }
          }
        }
      });
    }

    // HRV Chart
    const ctx2 = document.getElementById('hrvChart');
    if (ctx2) {
      new Chart(ctx2, {
        type: 'line',
        data: {
          labels: sessionHistory.slice(-10).map(s => new Date(s.date).toLocaleDateString()),
          datasets: [{
            label: 'Average HRV (ms)',
            data: sessionHistory.slice(-10).map(s => s.avgHRV),
            borderColor: '#FFC185',
            backgroundColor: 'rgba(255, 193, 133, 0.1)',
            tension: 0.4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: true,
              text: 'Heart Rate Variability Progress'
            }
          }
        }
      });
    }
  }, 100);
}

function loadSessionHistory() {
  const sessionHistory = loadFromLocalStorage('sessionHistory') || [];
  const historyContainer = document.getElementById('sessionHistory');
  
  historyContainer.innerHTML = '';

  if (sessionHistory.length === 0) {
    historyContainer.innerHTML = '<p>No sessions completed yet. Start your first session!</p>';
    return;
  }

  sessionHistory.slice().reverse().forEach(session => {
    const historyItem = document.createElement('div');
    historyItem.className = 'history-item';
    historyItem.innerHTML = `
      <div class="history-info">
        <h4>${session.technique || session.activity || 'Meditation Session'}</h4>
        <p>${new Date(session.date).toLocaleDateString()} at ${new Date(session.date).toLocaleTimeString()}</p>
      </div>
      <div class="history-stats">
        <div>${session.duration} minutes</div>
        <div>Avg HR: ${session.avgHR}</div>
        <div>Final State: ${session.finalStressLevel}</div>
      </div>
    `;
    historyContainer.appendChild(historyItem);
  });
}

function loadAchievementsDisplay() {
  const achievementsGrid = document.getElementById('achievementsGrid');
  const earnedAchievements = loadFromLocalStorage('achievements') || [];
  
  achievementsGrid.innerHTML = '';

  APP_DATA.achievements.forEach(achievement => {
    const isEarned = earnedAchievements.some(a => a.name === achievement.name);
    
    const achievementItem = document.createElement('div');
    achievementItem.className = `achievement-item ${isEarned ? 'earned' : 'locked'}`;
    achievementItem.innerHTML = `
      <div class="achievement-icon">${achievement.icon}</div>
      <div class="achievement-info">
        <h4>${achievement.name}</h4>
        <p>${achievement.description}</p>
        ${isEarned ? '<p style="color: #10b981; font-size: 12px; margin-top: 4px;">✓ Earned</p>' : ''}
      </div>
    `;
    achievementsGrid.appendChild(achievementItem);
  });
}

// Settings
function loadSettings() {
  const user = appState.user;
  if (user) {
    document.getElementById('settingsName').value = user.name;
    document.getElementById('settingsAge').value = user.age;
  }
}

function updateProfile() {
  const newName = document.getElementById('settingsName').value;
  const newAge = document.getElementById('settingsAge').value;

  if (newName && newAge) {
    appState.user.name = newName;
    appState.user.age = parseInt(newAge);
    saveToLocalStorage('user', appState.user);
    alert('Profile updated successfully!');
    updateDashboard();
  }
}

function exportData() {
  const user = loadFromLocalStorage('user');
  const sessionHistory = loadFromLocalStorage('sessionHistory');
  const achievements = loadFromLocalStorage('achievements');

  const exportData = {
    user: user,
    sessionHistory: sessionHistory,
    achievements: achievements,
    exportDate: new Date().toISOString()
  };

  const dataStr = JSON.stringify(exportData, null, 2);
  const dataBlob = new Blob([dataStr], {type: 'application/json'});
  const url = URL.createObjectURL(dataBlob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = `pranayama_data_${new Date().toISOString().split('T')[0]}.json`;
  link.click();
  
  URL.revokeObjectURL(url);
}

function deleteAllData() {
  if (confirm('Are you sure you want to delete all your data? This action cannot be undone.')) {
    if (confirm('This will permanently delete your profile, session history, and achievements. Continue?')) {
      localStorage.removeItem('pranayama_user');
      localStorage.removeItem('pranayama_sessionHistory');
      localStorage.removeItem('pranayama_achievements');
      
      alert('All data has been deleted.');
      location.reload();
    }
  }
}

function changeTheme() {
  const theme = document.getElementById('themeSelect').value;
  if (theme === 'light') {
    document.documentElement.setAttribute('data-color-scheme', 'light');
  } else if (theme === 'dark') {
    document.documentElement.setAttribute('data-color-scheme', 'dark');
  } else {
    document.documentElement.removeAttribute('data-color-scheme');
  }
  saveToLocalStorage('theme', theme);
}

// Initialize App
function initializeApp() {
  // Load saved user data
  const savedUser = loadFromLocalStorage('user');
  if (savedUser) {
    appState.user = savedUser;
    showDashboard();
  } else {
    showScreen('welcomeScreen');
  }

  // Load theme preference
  const savedTheme = loadFromLocalStorage('theme');
  if (savedTheme) {
    document.getElementById('themeSelect').value = savedTheme;
    changeTheme();
  }

  // Initialize vital signs
  generateRealisticVitalSigns('rest', 0);
}

// Start the application
document.addEventListener('DOMContentLoaded', initializeApp);